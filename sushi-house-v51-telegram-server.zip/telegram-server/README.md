# Sushi House Telegram server

Separate backend for sending Sushi House orders to Telegram without exposing the bot token in the browser.

Render settings:
- Runtime: Node
- Root Directory: `telegram-server`
- Build Command: `npm install`
- Start Command: `npm start`
- Environment: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `ALLOWED_ORIGIN=https://sushi-house-9clk.onrender.com`

Health check: `/health`
Order endpoint: `POST /api/order`
